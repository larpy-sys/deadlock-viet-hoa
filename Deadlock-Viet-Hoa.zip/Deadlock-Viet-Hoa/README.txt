VIET HOA DEADLOCK (ban chua hoan thien)
=======================================

CACH CAI
1. Giai nen toan bo thu muc nay (dung chay trong file zip).
2. TAT HAN Deadlock. Bam dup Cai-Viet-Hoa.bat.
   Script tu tim Deadlock qua Steam, sao luu gameinfo.gi (gameinfo.gi.bak-vi),
   them "vietnamese" vao danh sach ngon ngu va chep cac file dich.
   Neu khong tim thay game, no se hoi duong dan thu muc Deadlock.
3. Steam > chuot phai Deadlock > Properties > Launch Options, nhap:
       -language vietnamese
4. Mo game. Phai tat han roi mo lai, khong chi thoat ve menu.

CAP NHAT KHI CO BAN MOI
Sau khi cai, tren Desktop co shortcut "Cap nhat Viet hoa Deadlock" (hoac chay Cap-Nhat-Viet-Hoa.bat).
Tat han game, bam dup no: script so phien ban voi ban moi nhat, neu moi hon thi tai ve va cai de len.
Khong can tai lai ca goi. Neu bao "chua co dia chi cap nhat" thi nguoi gui chua dien update-url.txt:
hay xin ban moi tu nguoi gui.

GO CAI DAT
Bam dup Go-Viet-Hoa.bat (cung go luon shortcut cap nhat), roi xoa "-language vietnamese" khoi Launch Options.

LUU Y
- Steam cap nhat game hoac "Verify integrity" co the ghi de file. Khi do chay lai Cai-Viet-Hoa.bat.
- Ban dich chua hoan thien: ten vat pham, ten bo vu khi, ten rieng van la tieng Anh (co chu y).
- Ban dich do game cung cap tuy chon ngon ngu khong chinh thuc, co the loi font o vai ky tu.
- Day la mod ca nhan, khong lien quan Valve. Neu gap loi, go cai dat bang Go-Viet-Hoa.bat.
- Neu game khong khoi dong sau khi cai: chay Go-Viet-Hoa.bat va bao lai.
