param([string]$GameDir = '')
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$locSrc = Join-Path $here 'loc'

function Find-Deadlock {
    $roots = @()
    foreach ($k in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
        try {
            $p = (Get-ItemProperty $k -ErrorAction Stop)
            if ($p.SteamPath) { $roots += ($p.SteamPath -replace '/','\') }
            if ($p.InstallPath) { $roots += $p.InstallPath }
        } catch {}
    }
    $libs = @()
    foreach ($r in ($roots | Select-Object -Unique)) {
        $libs += $r
        $vdf = Join-Path $r 'steamapps\libraryfolders.vdf'
        if (Test-Path $vdf) {
            foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"')) {
                $libs += ($m.Groups[1].Value -replace '\\\\','\')
            }
        }
    }
    foreach ($l in ($libs | Select-Object -Unique)) {
        $d = Join-Path $l 'steamapps\common\Deadlock'
        if (Test-Path (Join-Path $d 'game\citadel\gameinfo.gi')) { return $d }
    }
    return $null
}

Write-Host '=== Cai Viet hoa Deadlock ===' -ForegroundColor Cyan
if (Get-Process -Name deadlock -ErrorAction SilentlyContinue) {
    Write-Host 'Deadlock dang chay. Hay tat game hoan toan roi chay lai file nay.' -ForegroundColor Yellow
    exit 1
}
$dl = $null
if ($GameDir -and (Test-Path (Join-Path $GameDir 'game\citadel\gameinfo.gi'))) { $dl = $GameDir.TrimEnd('\') }
if (-not $dl) { $dl = Find-Deadlock }
if (-not $dl) {
    Write-Host 'Khong tu tim thay Deadlock.' -ForegroundColor Yellow
    $dl = Read-Host 'Dan duong dan thu muc Deadlock (vd D:\SteamLibrary\steamapps\common\Deadlock)'
    $dl = $dl.Trim('"').TrimEnd('\')
    if (-not (Test-Path (Join-Path $dl 'game\citadel\gameinfo.gi'))) { Write-Host 'Duong dan sai.' -ForegroundColor Red; exit 1 }
}
Write-Host "Tim thay Deadlock: $dl"

$gi = Join-Path $dl 'game\citadel\gameinfo.gi'
$bak = $gi + '.bak-vi'
if (-not (Test-Path $bak)) { Copy-Item $gi $bak; Write-Host 'Da sao luu gameinfo.gi -> gameinfo.gi.bak-vi' }

$enc = [Text.Encoding]::GetEncoding(28591)   # Latin1: giu nguyen tung byte
$txt = [IO.File]::ReadAllText($gi, $enc)
if ($txt -match '"vietnamese"') {
    Write-Host 'gameinfo.gi da co vietnamese, bo qua.'
} else {
    $re = [regex]::new('("english"\s+"3")(\r?\n)(\s*)')
    $new = $re.Replace($txt, { param($m) $m.Groups[1].Value + $m.Groups[2].Value + $m.Groups[3].Value + '"vietnamese" "3"' + $m.Groups[2].Value + $m.Groups[3].Value }, 1)
    if ($new -eq $txt) { Write-Host 'Khong sua duoc gameinfo.gi (cau truc khac thuong).' -ForegroundColor Red; exit 1 }
    [IO.File]::WriteAllText($gi, $new, $enc)
    Write-Host 'Da them vietnamese vao gameinfo.gi'
}

$n = 0
foreach ($d in Get-ChildItem $locSrc -Directory) {
    $dst = Join-Path $dl ('game\citadel\resource\localization\' + $d.Name)
    New-Item -ItemType Directory -Force $dst | Out-Null
    foreach ($f in Get-ChildItem $d.FullName -File) { Copy-Item $f.FullName $dst -Force; $n++ }
}
Write-Host "Da chep $n file ngon ngu." -ForegroundColor Green

# --- Cap nhat nhanh: luu ban cap nhat + phien ban dang cai ---
function Copy-IfDiff($src, $dstDir) {
    $dst = Join-Path $dstDir (Split-Path -Leaf $src)
    if ((Test-Path $dst) -and ((Get-FileHash $src).Hash -eq (Get-FileHash $dst).Hash)) { return }
    Copy-Item $src $dst -Force
}
function Has-Url($p) {
    if (-not (Test-Path $p)) { return $false }
    foreach ($l in (Get-Content $p)) { $t = $l.Trim(); if ($t -and -not $t.StartsWith('#')) { return $true } }
    return $false
}
try {
    $st = Join-Path $env:LOCALAPPDATA 'DeadlockVietHoa'
    New-Item -ItemType Directory -Force $st | Out-Null
    foreach ($f in @('Cap-Nhat-Viet-Hoa.ps1','Cap-Nhat-Viet-Hoa.bat','version.txt')) {
        $sp = Join-Path $here $f
        if (Test-Path $sp) { try { Copy-IfDiff $sp $st } catch {} }
    }
    $up = Join-Path $here 'update-url.txt'
    if (Has-Url $up) { Copy-Item $up $st -Force }
    Set-Content -Path (Join-Path $st 'game-dir.txt') -Value $dl -Encoding ASCII
    try {
        $ws = New-Object -ComObject WScript.Shell
        $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Cap nhat Viet hoa Deadlock.lnk'))
        $lnk.TargetPath = Join-Path $st 'Cap-Nhat-Viet-Hoa.bat'
        $lnk.WorkingDirectory = $st
        $lnk.Save()
    } catch {}
} catch {
    Write-Host 'Khong cai duoc tinh nang cap nhat nhanh (khong anh huong ban dich).' -ForegroundColor Yellow
}
Write-Host ''
Write-Host 'BUOC CUOI: Steam > chuot phai Deadlock > Properties > Launch Options, nhap:' -ForegroundColor Cyan
Write-Host '    -language vietnamese' -ForegroundColor White
Write-Host 'Roi TAT HAN game (neu dang mo) va mo lai.'
