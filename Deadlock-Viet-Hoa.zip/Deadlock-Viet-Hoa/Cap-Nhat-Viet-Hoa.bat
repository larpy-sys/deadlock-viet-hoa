@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Cap-Nhat-Viet-Hoa.ps1"
pause
