$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$state = Join-Path $env:LOCALAPPDATA 'DeadlockVietHoa'

function Get-FirstLine($p) {
    if (Test-Path $p) {
        foreach ($l in (Get-Content $p)) {
            $t = $l.Trim()
            if ($t -and -not $t.StartsWith('#')) { return $t }
        }
    }
    return $null
}

Write-Host '=== Cap nhat Viet hoa Deadlock ===' -ForegroundColor Cyan
$base = Get-FirstLine (Join-Path $here 'update-url.txt')
if (-not $base) {
    Write-Host 'Chua co dia chi cap nhat (file update-url.txt dang trong).' -ForegroundColor Yellow
    Write-Host 'Hay hoi nguoi gui ban viet hoa cho ban de lay ban moi.'
    exit 1
}
$base = $base.TrimEnd('/')
$cur = Get-FirstLine (Join-Path $state 'version.txt')
if (-not $cur) { $cur = Get-FirstLine (Join-Path $here 'version.txt') }
if (-not $cur) { $cur = '(khong ro)' }
Write-Host "Phien ban dang cai: $cur"

if (Get-Process -Name deadlock -ErrorAction SilentlyContinue) {
    Write-Host 'Deadlock dang chay. Hay tat game hoan toan roi chay lai file nay.' -ForegroundColor Yellow
    exit 1
}

try {
    $r = Invoke-WebRequest -Uri "$base/version.txt" -UseBasicParsing -TimeoutSec 20
} catch {
    Write-Host 'Khong ket noi duoc may chu cap nhat. Kiem tra mang roi thu lai.' -ForegroundColor Red
    exit 1
}
$txt = $r.Content
if ($txt -is [byte[]]) { $txt = [Text.Encoding]::UTF8.GetString($txt) }
$txt = $txt.TrimStart([char]0xFEFF)
$lines = @(($txt -split "`r?`n") | ForEach-Object { $_.Trim() } | Where-Object { $_ })
if ($lines.Count -lt 1) { Write-Host 'File version tren may chu bi loi.' -ForegroundColor Red; exit 1 }
$new = $lines[0]
$sha = ''
if ($lines.Count -ge 2) { $sha = $lines[1] }
Write-Host "Phien ban moi nhat: $new"
if ($new -eq $cur) {
    Write-Host 'Ban dang dung ban moi nhat.' -ForegroundColor Green
    exit 0
}

$tmp = Join-Path $env:TEMP ('vh_' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force $tmp | Out-Null
try {
    $zip = Join-Path $tmp 'vh.zip'
    Write-Host 'Dang tai ban cap nhat...'
    Invoke-WebRequest -Uri "$base/Deadlock-Viet-Hoa.zip" -OutFile $zip -UseBasicParsing -TimeoutSec 120
    if ($sha -match '^[0-9a-fA-F]{64}$') {
        $h = (Get-FileHash $zip -Algorithm SHA256).Hash
        if ($h -ne $sha.ToUpper()) {
            Write-Host 'File tai ve bi hong hoac khong khop (sai ma kiem tra). Khong cai.' -ForegroundColor Red
            exit 1
        }
    }
    $ex = Join-Path $tmp 'x'
    Expand-Archive -Path $zip -DestinationPath $ex -Force
    $inst = Get-ChildItem $ex -Recurse -Filter 'Cai-Viet-Hoa.ps1' | Select-Object -First 1
    if (-not $inst) { Write-Host 'Goi cap nhat khong hop le.' -ForegroundColor Red; exit 1 }
    $gd = Get-FirstLine (Join-Path $state 'game-dir.txt')
    $a = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$inst.FullName)
    if ($gd -and (Test-Path $gd)) { $a += @('-GameDir',$gd) }
    & powershell @a
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'Cap nhat that bai. Ban dich cu van con nguyen.' -ForegroundColor Red
        exit 1
    }
    Write-Host ''
    Write-Host "Da cap nhat len $new. Tat han game roi mo lai de thay doi." -ForegroundColor Green
} finally {
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
