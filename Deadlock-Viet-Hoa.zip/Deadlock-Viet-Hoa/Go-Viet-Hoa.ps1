$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$dl = $null
foreach ($k in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
    try { $p = Get-ItemProperty $k -ErrorAction Stop; foreach ($r in @(($p.SteamPath -replace '/','\'),$p.InstallPath)) { if ($r) {
        $libs=@($r); $vdf=Join-Path $r 'steamapps\libraryfolders.vdf'
        if (Test-Path $vdf) { foreach ($m in [regex]::Matches((Get-Content $vdf -Raw),'"path"\s+"([^"]+)"')) { $libs += ($m.Groups[1].Value -replace '\\\\','\') } }
        foreach ($l in $libs) { $d=Join-Path $l 'steamapps\common\Deadlock'; if (-not $dl -and (Test-Path (Join-Path $d 'game\citadel\gameinfo.gi'))) { $dl=$d } } } } } catch {}
}
if (-not $dl) { $dl = (Read-Host 'Dan duong dan thu muc Deadlock').Trim('"').TrimEnd('\') }
$gi = Join-Path $dl 'game\citadel\gameinfo.gi'
if (Test-Path ($gi + '.bak-vi')) { Copy-Item ($gi + '.bak-vi') $gi -Force; Write-Host 'Da khoi phuc gameinfo.gi' }
Get-ChildItem (Join-Path $dl 'game\citadel\resource\localization') -Recurse -Filter '*_vietnamese.txt' | Remove-Item -Force
Write-Host 'Da go Viet hoa. Nho xoa "-language vietnamese" khoi Launch Options.' -ForegroundColor Green
Remove-Item (Join-Path $env:LOCALAPPDATA 'DeadlockVietHoa') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Cap nhat Viet hoa Deadlock.lnk') -Force -ErrorAction SilentlyContinue
