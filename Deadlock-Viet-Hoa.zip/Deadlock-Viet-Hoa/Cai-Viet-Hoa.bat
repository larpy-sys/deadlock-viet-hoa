@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Cai-Viet-Hoa.ps1"
pause
