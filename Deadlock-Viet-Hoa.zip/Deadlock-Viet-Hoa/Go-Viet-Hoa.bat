@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Go-Viet-Hoa.ps1"
pause
